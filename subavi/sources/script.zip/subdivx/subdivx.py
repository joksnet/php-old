#!/usr/bin/env python

from UnRAR import Archive
from zipfile import ZipFile
from urllib import urlopen, urlretrieve
from re import findall
from os import remove, rename
from os.path import exists
from time import time
from MySQLdb import connect

class Subdivx:
    """BOT para descargar subtitulos de Subdivx"""

    verbose = True
    regexp = {
        'subtitle' : '<a class="nu" href="http://www.subdivx.com/([^>]+)"><font face="verdana" size="2" color="#000000"><b>([^>]+)</b></font></a>',
        'comment'  : '<br><div align="center"><font face="verdana" size="1" color="black">(.*?)</div></font>',
        'nums'     : '<div align="right"><font face="verdana" size="1" color="black"><b>Downloads:</b> (\d+) </font><font face="verdana" size="1" color="black"><b>Cds:</b> (\d+) </font><font face="verdana" size="1" color="black"><b>Comentarios:</b> (\d+) </font>',
        'format'   : '<font face="verdana" size="1" color="black"><b>Formato:</b> ([^>]+) </font>',
        'credits'  : '<font face="verdana" size="1" color="black"><b>Subido por:</b> <a class="nu" href="http://www.subdivx.com/([^>]+)">([^>]+)</a>',
        'fps'      : '<td width="254" bgcolor="#b1b78b" align="right"><font face="Verdana" size="1">([^>]+) fps&nbsp;</font></td>',
        'download' : '<a class="nublack"  href="http://www.subdivx.com/([^>]+)"><font size="6">Bajar Subt.tulo Ahora</font></a><br><br>',
        'file'     : '<a href="http://files..subdivx.com/([^>]+)">haz click aqu.</a>'
    }
    extensions = ['srt', 'sub', 'ssa']

    def __init__(self, db_config):
        try:
            db = connect(host=db_config['host'], user=db_config['user'], passwd=db_config['passwd'], db=db_config['db'])
        except:
            if self.verbose:
                print 'Cant\'t connect to Database'
            exit()

        self.db = db.cursor()

    def _error(self, error, info):
        try:
            self.db.execute("INSERT INTO errors ( error, info ) VALUES ( %s, %s )", [error, info])
        except:
            pass

    def _url(self, url):
        try:
            page = urlopen('http://subdivx.com/' + url)
            pagecontent = page.read()
            page.close()
        except:
            return None

        return pagecontent

    def _url_retry(self, url, times=2):
        retry = 0
        html = None

        while retry < times:
            html = self._url(url)
            retry += 1

            if html:
                retry = times

        if not html:
            return None
        else:
            return html

    def _url_retrieve(self, url, filename, forceContentType=None):
        try:
            filename2, headers = urlretrieve(url, filename)

            if forceContentType:
                if not forceContentType in headers['Content-Type']:
                    if filename2:
                        remove(filename2)
                    return None

            return (filename2, headers)
        except:
            return None

    def _subtitle_download(self, id, format):
        filename = str(id) + '.' + str(format)
        fileservermax = 2
        filetype = 'application/' + str(format)

        for i in range(1, fileservermax + 1):
            fileserver = 'http://files' + str(i) + '.subdivx.com/'
            fileinfo = self._url_retrieve(fileserver + filename, 'files/' + filename, filetype)

            if fileinfo:
                break

        if not fileinfo:
            return None

        return fileinfo

    def _subtitle_extract(self, id, format, download=True):
        if download:
            fileinfo = self._subtitle_download(id, format)

            if not fileinfo:
                return None

        if format == 'zip':
            return self._subtitle_extract_zip(id, format)
        elif format == 'rar':
            return self._subtitle_extract_rar(id, format)

    def _subtitle_extract_zip(self, id, format):
        if not format == 'zip':
            return [str(id) + '.' + str(format)]

        filename = 'files/' + str(id) + '.' + str(format)

        try:
            zf = ZipFile(filename)
        except:
            return []

        filetmp = 0
        files = []

        for i, fileInArchive in enumerate(zf.namelist()):
            extract = False

            for ext in self.extensions:
                if fileInArchive.endswith(ext):
                    extract = True
                    break

            if extract:
                filetemporal = str(id) + '_' + str(filetmp) + '.tmp'

                try:
                    outcontent = zf.read(fileInArchive)
                except:
                    continue

                outfile = open(filetemporal, 'wb')
                outfile.write(outcontent)
                outfile.flush()
                outfile.close()

                files.append((filetemporal, fileInArchive))
                filetmp += 1

        return files

    def _subtitle_extract_rar(self, id, format):
        if not format == 'rar':
            return [str(id) + '.' + str(format)]

        filename = 'files/' + str(id) + '.' + str(format)

        try:
            fileArchive = Archive(filename)
            filesInArchive = fileArchive.iterfiles()
        except:
            return []

        filetmp = 0
        files = []

        for fileInArchive in filesInArchive:
            extract = False

            for ext in self.extensions:
                if fileInArchive.filename.endswith(ext):
                    extract = True
                    break

            if extract:
                try:
                    filetemporal = str(id) + '_' + str(filetmp) + '.tmp'
                    fileInArchive.extract(filetemporal)

                    files.append((filetemporal, fileInArchive.filename))
                    filetmp += 1
                except:
                    pass

        return files

    def _subtitle_files(self, id, files, data):
        if not files:
            return 

        for filetemp, filename in files:
            parts = filename.split('.')
            extension = parts.pop()
            fileonly = '.'.join(parts)

            if '\\' in fileonly:
                parts2 = fileonly.split('\\')
                fileonly = parts2.pop()

            self.db.execute("INSERT INTO subdivx_files VALUES ( %s, %s, %s )", [str(id), fileonly, extension])
            self.db.execute("INSERT INTO subs ( filename, ext, frame, comment, credits, time ) VALUES ( %s, %s, %s, %s, %s, %s )", [fileonly, extension, data['fps'], data['comment'], data['user'], str(int(time()))])
            self.db.execute("SELECT last_insert_id()")

            newid_query = self.db.fetchone()

            if not newid_query:
                continue

            if not exists(filetemp):
                continue

            rename(filetemp, 'subs/' + str(newid_query[0]))

    def _page(self, page, n=0):
        if self.verbose:
            print
            print 'Page ' + str(page) + ' (' + str(n) + ')'
            print '--'

        html = self._url_retry('X1X' + str(page))

        if not html:
            self._error(1, 'Page "X1X' + str(page) + '" Empty')
            return None

        regexp = self.regexp['subtitle'] + self.regexp['comment'] + self.regexp['nums'] \
               + self.regexp['format']   + self.regexp['credits']

        subs = findall(regexp, html)

        subsn = 0
        subsignored = 0
        subtitles = []

        if not subs:
            self._error(2, 'None RE on page "X1X' + str(page) + '"')
            return None

        for sub in subs:
            subid = 0
            subfileformat = ''
            subinfo = self._page_subtitle(sub[0])

            if not subinfo:
                subinfo = [0, '', '']

            if subinfo[2]:
                parts = subinfo[2].split('.')

                subfileformat = parts.pop()
                subid = '.'.join(parts)

                if subid.isdigit():
                    subid = int(subid)
                else:
                    self._error(7, 'SubID [' + str(subid) + ']: NO ES Digito')

            subdict = {
                'id'          : str(subid),
                'name'        : str(sub[1]),
                'url'         : str(sub[0]),
                'urldownload' : str(subinfo[1]),
                'server'      : str(''),
                'comment'     : str(sub[2]),
                'downloads'   : str(sub[3]),
                'cds'         : str(sub[4]),
                'comments'    : str(sub[5]),
                'format'      : str(sub[6]),
                'user'        : str(sub[8]),
                'userurl'     : str(sub[7]),
                'fps'         : str(subinfo[0]),
                'filename'    : str(subinfo[2]),
                'fileformat'  : str(subfileformat),
                'time'        : str(int(time()))
            }

            self.db.execute("SELECT * FROM subdivx WHERE id = %s", [str(subid)])

            if self.db.fetchone():
                print subid, 'ignored'

                try:
                    self.db.execute("INSERT INTO ignores VALUES ( %s )", [str(subid)])
                except:
                    # Ya existe en "ignores". Ignorado.
                    pass

                subsignored += 1
                continue

            files = self._subtitle_extract(subid, subfileformat)

            if files:
                self._subtitle_files(subid, files, subdict)

            ##
            # Lo inserto en la tabla "subdivx".
            self.db.execute("INSERT INTO subdivx VALUES ( %(id)s, %(name)s, %(url)s, %(urldownload)s, %(server)s, %(comment)s, %(downloads)s, %(cds)s, %(comments)s, %(format)s, %(user)s, %(userurl)s, %(fps)s, %(filename)s, %(fileformat)s, %(time)s )", subdict)

            subsn += 1
            subtitles.append(subdict)

            if self.verbose:
                print subid, sub[1]

            if subsn >= n and n > 0:
                break

        return (subtitles, subsignored)

    def _page_subtitle(self, url):
        html = self._url_retry(url)

        if not html:
            self._error(3, 'Subtitle URL "' + url + '" Empty')
            return None

        fps_re = findall(self.regexp['fps'], html)
        fps = 0

        if not fps_re:
            self._error(4, 'Can\'t RE fps on "' + url + '"')
        else:
            fps = fps_re[0]

            if fps.strip().lower() == 'n/a':
                fps = 0
            if not str(fps).isdigit():
                fps = 0

        download_re = findall(self.regexp['download'], html)
        download = ''

        filename = ''

        if not download_re:
            self._error(5, 'Can\'t RE download URL on "' + url + '"')
        else:
            download = download_re[0]
            filename_tmp = self._page_subtitle_download(download)

            if filename_tmp:
                filename = filename_tmp

        return [fps, download, filename]

    def _page_subtitle_download(self, url):
        html = self._url_retry(url)

        if not html:
            self._error(6, 'Subtitle Download URL "' + url + '" Empty')
            return None

        filename_re = findall(self.regexp['file'], html)
        filename = ''

        if not filename_re:
            self._error(7, 'Can\'t RE filename on "' + url + '"')
        else:
            filename = filename_re[0]

        return filename

    def last(self, n=0, p=0):
        last = []

        page = p
        subs = 0

        while True:
            pagen = 0

            if n - subs < 20:
                pagen = n - subs

            pageresult = self._page(page, pagen)

            if not pageresult:
                self._error(8, 'Page "' + str(page) + '" Ignored')
                page += 1
                continue

            subtitles, ignored = pageresult

            if subtitles is None or ( len(subtitles) == 0 and ignored == 0 ):
                self._error(9, 'Page "' + str(page) + '" Ignored')
                page += 1
                continue

            subs += len(subtitles)
            last += subtitles

            if subs >= n and n > 0:
                break

            page += 1

        if self.verbose:
            print 
            print '--'
            print subs, 'subtitles in', page + 1, 'pages'

        return last

if __name__ == '__main__':
    db_config = {
        'host'   : 'localhost',
        'user'   : 'subdivx',
        'passwd' : 'subdivx',
        'db'     : 'subdivx'
    }

    subdivx = Subdivx(db_config)
    subdivx.last(0, 0)