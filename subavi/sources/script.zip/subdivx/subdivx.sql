
DROP TABLE IF EXISTS errors;
CREATE TABLE IF NOT EXISTS errors (
  error mediumint(3) unsigned NOT NULL DEFAULT '' ,
  info text NOT NULL DEFAULT '' 
);

DROP TABLE IF EXISTS ignores;
CREATE TABLE IF NOT EXISTS ignores (
  id mediumint(8) unsigned NOT NULL DEFAULT '' ,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS subdivx;
CREATE TABLE IF NOT EXISTS subdivx (
  id mediumint(8) unsigned NOT NULL DEFAULT '' ,
  name varchar(200) NOT NULL DEFAULT '' ,
  url varchar(200) NOT NULL DEFAULT '' ,
  urldownload varchar(200) NOT NULL DEFAULT '' ,
  server varchar(10) NOT NULL DEFAULT '' ,
  comment text NOT NULL DEFAULT '' ,
  downloads mediumint(5) NOT NULL DEFAULT '0' ,
  cds tinyint(2) unsigned NOT NULL DEFAULT '0' ,
  coments tinyint(3) unsigned NOT NULL DEFAULT '0' ,
  format varchar(50) NOT NULL DEFAULT '' ,
  user varchar(50) NOT NULL DEFAULT '' ,
  userurl varchar(200) NOT NULL DEFAULT '' ,
  fps float(6,3) NOT NULL DEFAULT '0.000' ,
  filename varchar(100) NOT NULL DEFAULT '' ,
  fileformat varchar(3) NOT NULL DEFAULT '' ,
  time int(14) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS subdivx_files;
CREATE TABLE IF NOT EXISTS subdivx_files (
  id mediumint(8) unsigned NOT NULL DEFAULT '0' ,
  filename varchar(200) NOT NULL DEFAULT '' ,
  ext varchar(3) NOT NULL DEFAULT '' ,
   KEY id (id)
);

DROP TABLE IF EXISTS subs;
CREATE TABLE IF NOT EXISTS subs (
  id mediumint(8) unsigned NOT NULL auto_increment,
  filename varchar(255) NOT NULL DEFAULT '' ,
  ext varchar(3) NOT NULL DEFAULT '' ,
  frame float(6,3) NOT NULL DEFAULT '0.000' ,
  comment text NOT NULL DEFAULT '' ,
  credits varchar(64) NOT NULL DEFAULT '' ,
  downloads mediumint(8) unsigned NOT NULL DEFAULT '0' ,
  time int(14) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (id)
);