<?php

/**
 * @author Juan M Martinez <joksnet@gmail.com>
 */
class Formats
{
    /**
     * @var array
     */
    protected static $formats = null;

    /**
     * @param string $ext
     * @return mixed
     */
    public static function get( $ext )
    {
        if ( null === self::$formats )
        {
            $data = Db::query(
                "SELECT f.ext, f.name
                 FROM formats f"
            );

            foreach ( (array) $data as $row )
                self::$formats[$row['ext']] = $row['name'];
        }

        if ( isset(self::$formats[$ext]) )
            return self::$formats[$ext];
        else
            return null;
    }
}