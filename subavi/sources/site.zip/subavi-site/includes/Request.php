<?php

/**
 * @author Juan M Martinez <joksnet@gmail.com>
 */
class Request
{
    /**
     * @return boolean
     */
    public static function isPost()
    {
        return ( sizeof($_POST) > 0 );
    }

    /**
     * @param string $var
     * @param mixed $default
     * @return mixed
     */
    public static function getPost( $var, $default = null )
    {
        return ( isset($_POST[$var]) ) ? $_POST[$var] : $default;
    }

    /**
     * @param string $var
     * @return boolean
     */
    public static function hasPost( $var )
    {
        return ( isset($_POST[$var]) );
    }

    /**
     * @param string $var
     * @param mixed $default
     * @return mixed
     */
    public static function getQuery( $var, $default = null )
    {
        return ( isset($_GET[$var]) ) ? $_GET[$var] : $default;
    }

    /**
     * @param string $var
     * @return boolean
     */
    public static function hasQuery( $var )
    {
        return ( isset($_GET[$var]) );
    }
}