<?php Theme::_('Header', array( 'title' => 'no se encontr� el subt�tulo � Subt�tulos' )); ?>

<h1>no se encontr&oacute; el subt&iacute;tulo</h1>
<ul>
  <li>Comprob&aacute; lo escrito</li>
  <li>Us&aacute; nombres parciales</li>
  <li>Ingres&aacute; m&aacute;s de 2 caracteres</li>
</ul>

<?php Theme::_('Footer'); ?>