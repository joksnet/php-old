<?php

/**
 * Este es un ejemplo de como seria el archivo config.php
 *
 * IMPORTANTE: El archivo config.php __NO__ hay que incluirlo al hacer el
 * commit, queda local unicamente !
 */

$dbConfig = array(
    'hostname' => 'localhost',
    'username' => 'root',
    'password' => 'secret',
    'database' => 'subavi'
);