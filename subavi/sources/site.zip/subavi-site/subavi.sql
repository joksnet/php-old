
DROP TABLE IF EXISTS config;
CREATE TABLE IF NOT EXISTS config (
  name varchar(32) NOT NULL DEFAULT '' ,
  value varchar(160) NOT NULL DEFAULT '' ,
  PRIMARY KEY (name)
);

INSERT INTO config (name, value) VALUES("siteName", "Subavi");
INSERT INTO config (name, value) VALUES("siteTheme", "default");
INSERT INTO config (name, value) VALUES("siteTagline", "Subt�tulos en espa�ol");
INSERT INTO config (name, value) VALUES("siteDescription", "Subavi.com.ar | Sitio para descargar subt�tulos de divx en espa�ol para peliculas, series, y m�s...");
INSERT INTO config (name, value) VALUES("siteKeywords", "subavi, subt�tulo, sub, pelicula, serie, serie de tv, cine, divx, xdiv, descargar, espa�ol, castellano");

DROP TABLE IF EXISTS formats;
CREATE TABLE IF NOT EXISTS formats (
  ext varchar(3) NOT NULL DEFAULT '' ,
  name varchar(32) NOT NULL DEFAULT '' ,
  PRIMARY KEY (ext),
  UNIQUE KEY ext (ext)
);

INSERT INTO formats (ext, name) VALUES("srt", "SubRip");
INSERT INTO formats (ext, name) VALUES("sub", "MicroDVD");
INSERT INTO formats (ext, name) VALUES("ssa", "SubStation Alpha");

DROP TABLE IF EXISTS search;
CREATE TABLE IF NOT EXISTS search (
  id mediumint(8) unsigned NOT NULL auto_increment,
  query varchar(255) NOT NULL DEFAULT '' ,
  cant mediumint(8) unsigned NOT NULL DEFAULT '0' ,
  ids text NOT NULL DEFAULT '' ,
  time int(14) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (id),
  UNIQUE KEY query (query)
);

DROP TABLE IF EXISTS subs;
CREATE TABLE IF NOT EXISTS subs (
  id mediumint(8) unsigned NOT NULL auto_increment,
  filename varchar(255) NOT NULL DEFAULT '' ,
  ext varchar(3) NOT NULL DEFAULT '' ,
  frame float(6,3) NOT NULL DEFAULT '0.000' ,
  comment text NOT NULL DEFAULT '' ,
  credits varchar(64) NOT NULL DEFAULT '' ,
  credits2 varchar(64) NOT NULL DEFAULT '' ,
  downloads mediumint(8) unsigned NOT NULL DEFAULT '0' ,
  time int(14) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (id)
);