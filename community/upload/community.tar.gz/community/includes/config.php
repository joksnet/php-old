<?php

$db_config = array(
    'hostname' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'community'
);

$db_prefix = '';

?>
