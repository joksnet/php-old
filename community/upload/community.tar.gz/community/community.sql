-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1-Debian-1ubuntu1.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 03, 2006 at 01:29 PM
-- Server version: 4.0.24
-- PHP Version: 4.4.0-3ubuntu2
-- 
-- Database: `community`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id_comments` bigint(20) unsigned NOT NULL auto_increment,
  `id_posts` bigint(20) NOT NULL default '0',
  `author` tinytext NOT NULL,
  `author_email` varchar(100) NOT NULL default '',
  `author_url` varchar(200) NOT NULL default '',
  `author_ip` varchar(100) NOT NULL default '',
  `agent` varchar(255) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `content` text NOT NULL,
  `approved` enum('no','yes','spam') NOT NULL default 'yes',
  PRIMARY KEY  (`id_comments`)
) TYPE=MyISAM AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `comments`
-- 

INSERT INTO `comments` VALUES (1, 3, 'Leonardo Cantelmo', 'lcantelmo@gmail.com', 'http://telmux.com.ar/', '201.252.15.214', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.12) Gecko/20051010 Firefox/1.0.7 (Ubuntu package 1.0.7)', '2006-04-20 12:47:52', 'muy bien!!!\r\nme parece que fuiste el unico que se dedico a leer la spec de joksnet para que tu post quede bonito.\r\nlos demas somos re losers!', 'yes');
INSERT INTO `comments` VALUES (2, 3, 'Ignacio Soubelet', 'imsoubelet@bas.com.ar', '', '200.69.226.101', 'Mozilla/5.0 (Windows; U; Windows NT 5.0; es-AR; rv:1.7.12) Gecko/20050919 Firefox/1.0.7', '2006-04-20 12:51:38', 'Totalmente!!', 'yes');
INSERT INTO `comments` VALUES (3, 3, 'joksnet', 'joksnet@gmail.com', '', '192.168.1.2', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.1) Gecko/20060413 Ubuntu/dapper Firefox/1.5.0.1', '2006-04-20 14:58:11', 'otro detalle... el < blockquote >, dentro, ponelo entre < p > asi de deja un padding y se ve mas lindo...', 'yes');
INSERT INTO `comments` VALUES (4, 5, 'telmux', 'lcantelmo@gmail.com', 'http://telmux.com.ar/', '201.252.15.214', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.12) Gecko/20051010 Firefox/1.0.7 (Ubuntu package 1.0.7)', '2006-04-21 08:51:59', '<p>\r\nnoo!!. bueno, veo que descubrieron la realidad.\r\nlo que pasa es que cuando nacimos, eramos siameses. tuvimos que convivir asi hasta hace unos pocos meses.\r\ngracias a una costosa operacion en EEUU pudimos separarnos, y en dos meses ya se estaba completando de regenerar nuestra otra mitad.\r\njeje... saludos.\r\npd: nunca nos confirmaron cual de los dos era el siames maldito y cual era el bueno. chan!\r\n</p>', 'yes');
INSERT INTO `comments` VALUES (5, 7, 'Pablo', 'pablogrigo@gmail.com', 'www.grigo.com.ar', '200.114.192.185', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; es-AR; rv:1.8.0.2) Gecko/20060308 Firefox/1.5.0.2', '2006-04-23 14:33:49', 'Hay uno de rol que es buenisimo, toda una obra de arte en PHP!', 'yes');
INSERT INTO `comments` VALUES (6, 8, 'joksnet', 'joksnet@gmail.com', '', '192.168.1.2', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.1) Gecko/20060413 Ubuntu/dapper Firefox/1.5.0.1', '2006-04-26 17:54:46', 'BIEN!, bien complejo, pero se entiende. Muy buen definicion de "tratados" entre dispositivos. Veremos nuestra impresora llamar por telefono ?', 'yes');
INSERT INTO `comments` VALUES (7, 8, 'telmux', 'lcantelmo@gmail.com', 'http://telmux.com.ar/', '201.252.63.56', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.13) Gecko/20060418 Firefox/1.0.8 (Ubuntu package 1.0.8)', '2006-04-27 08:29:11', 'me encanto. gracias por este magnifico post. esta es una de esas cosas por las que generalmente ni nos preocupamos, y no nos damos cuenta que es importante ponerse a pernsar en ello. no puedo esperar a ver como continuan las cosas en la parte 2...', 'yes');
INSERT INTO `comments` VALUES (8, 10, 'Nacho', 'imsoubelet@bas.com.ar', '', '200.69.226.101', 'Mozilla/5.0 (Windows; U; Windows NT 5.0; es-AR; rv:1.7.12) Gecko/20050919 Firefox/1.0.7', '2006-04-27 09:53:10', 'Buenisimo!\r\nCreen ustedes que esta es la mejor forma de versionar los softwares?. Es decir, incrementar el major-minor-revision segun lo modificado pronto estará en desuso??', 'yes');
INSERT INTO `comments` VALUES (9, 8, 'Pablo', 'pablogrigo@gmail.com', 'http://grigo.com.ar', '200.114.192.185', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; es-ES; rv:1.8.0.2) Gecko/20060308 Firefox/1.5.0.2', '2006-04-27 12:02:43', 'Buenísimo!, el problema va a estar cuando la PC a las 3am, cansada de tanto trabajo, le pida a la cafetera un cortado, Y ESTA SE LO DE !\r\nExcelente explicacion, espero ansioso la 2da parte', 'yes');
INSERT INTO `comments` VALUES (10, 8, 'Adrye', 'adrye@bas.com.ar', '', '200.69.226.101', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; FunWebProducts; SV1; .NET CLR 1.1.4322)', '2006-04-27 16:43:05', 'Te felicito por la explicación ya estoy esperando ansiosamente la parte dos...', 'yes');
INSERT INTO `comments` VALUES (11, 8, 'joksnet', 'joksnet@gmail.com', '', '192.168.1.2', 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.1) Gecko/20060413 Ubuntu/dapper Firefox/1.5.0.1', '2006-04-27 17:26:40', 'No quedo mas lindo ??? Que mania esa de usar acentos... existen las htmlentities. no ?', 'yes');

-- --------------------------------------------------------

-- 
-- Table structure for table `labels`
-- 

DROP TABLE IF EXISTS `labels`;
CREATE TABLE IF NOT EXISTS `labels` (
  `id_labels` bigint(20) NOT NULL auto_increment,
  `name` varchar(55) NOT NULL default '',
  `description` longtext NOT NULL,
  `parent` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id_labels`)
) TYPE=MyISAM AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `labels`
-- 

INSERT INTO `labels` VALUES (1, 'GNU/Linux', '', 0);
INSERT INTO `labels` VALUES (2, 'PHP', '', 0);
INSERT INTO `labels` VALUES (3, 'Programacion', '', 0);
INSERT INTO `labels` VALUES (4, 'Python', '', 0);
INSERT INTO `labels` VALUES (5, 'Java', '', 0);
INSERT INTO `labels` VALUES (6, 'null', '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `options`
-- 

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Dumping data for table `options`
-- 

INSERT INTO `options` VALUES ('site_name', '<strong>Freaks</strong> Community');
INSERT INTO `options` VALUES ('site_description', '(...)');
INSERT INTO `options` VALUES ('site_slogan', 'Blog by freaks. To freaks &amp; geeks.');
INSERT INTO `options` VALUES ('per_page', '10');
INSERT INTO `options` VALUES ('date_format', 'D d F Y');
INSERT INTO `options` VALUES ('site_url', 'http://joksnet.homelinux.org/community');
INSERT INTO `options` VALUES ('thumb_width', '150');
INSERT INTO `options` VALUES ('thumb_height', '150');

-- --------------------------------------------------------

-- 
-- Table structure for table `posts`
-- 

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id_posts` bigint(20) unsigned NOT NULL auto_increment,
  `id_users` bigint(20) NOT NULL default '0',
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `active` enum('yes','no','draft') NOT NULL default 'yes',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id_posts`)
) TYPE=MyISAM AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `posts`
-- 

INSERT INTO `posts` VALUES (1, 2, 'What a wonderful blog!!!', '<p>\r\nBuenas a todos  :)\r\n</p>\r\n<p>\r\nAntes que nada quiero felicitar al Señor joksnet (con S mayuscula) por la fantastica web que nos esta brindando. Espero poder publicar alguna que otra cosa interesante frecuentemente asi va creciendo de a poco nuestra community.\r\n</p>\r\n<p>\r\nBueno, por el momento no se me ocurre nada nuevo, asi que dense una vueltita cada tanto porque muy pronto estamos comenzando.\r\n</p>\r\n<p>\r\nAprovecho tambien y le mando saludos a los demas freaks colegas con los que compartimos la web.\r\nSaludos para todos!\r\n</p>\r\n<p>\r\ntelmux.\r\n</p>', 'yes', '2006-04-20 08:32:59', '2006-04-21 08:53:47');
INSERT INTO `posts` VALUES (2, 1, 'Y as&iacute; comienza la historia...', '<p>Hola a todos! Antes que nada me gustaria agradecer a joksnet por su trabajo en el site, el cual ha quedado "claro".</p>\r\n<p>Por si no lo saben, el proposito de este Blog es muy Freak y demasiado Geek. Cada uno de nosotros (los amigos Freaks) tenemos la responsabilidad de postear cosas que sirvan, que sean interesantes y la idea es usar este site para plasmar nuestros conocimientos espec&iacute;ficos en determinadas &Aacute;reas, as&iacute; que esperamos te sea de utilidad.</p>\r\n<p>El mapa de topics de los Blogs queda mas o menos asi (esta es solo la idea, luego cada uno de los autores de los blogs hablar&aacute; de lo que le interese):</p>\r\n<ul>\r\n  <li><b>Juan Manual Martinez</b> hablar&aacute; sobre Web Design con PHP.</li>\r\n  <li><b>Leonardo Cantelmo</b> postear&aacute; sobre programaci&oacute;n C++</li>\r\n  <li><b>Pablo Grigolatto</b> se centrar&aacute; en Linux; e</li>\r\n  <li><b>Ignacio Soubelet (yo)</b> hablar&aacute; de Java y sistemas distribuidos (con CORBA).</li>\r\n</ul>\r\n<p>Dejo un saludo a mis amigos freaks, and..<br />\r\nEnjoy it!!!!</p>', 'no', '2006-04-20 09:57:02', '2006-04-20 09:57:02');
INSERT INTO `posts` VALUES (3, 4, 'My First Post', '<p>Muy buenos dias mundo! Luego de largas discuciones y plantea(miento)s, logramos pone\r\nos de acuerdo y aca estamos arrancando este proyecto. Ante todo vamos a saca\r\nos el sombrero ante nuestro camarada Joksnet que consumio 101 horas y 100101 tazas de cafe para levantar este blog.</p>\r\n<p>Que les puedo decir? Pronto empezaremos a postear cosas utiles, asi que chequeen seguido la web. Un saludo para todos los freaks de ahi a la derecha, nos vemos!</p>\r\n<blockquote>\r\n<p><i><center>Existen 10 tipos de personas, las que entienden binario, y las que no<center></i></p>\r\n</blockquote>', 'yes', '2006-04-20 10:47:33', '2006-04-28 15:42:30');
INSERT INTO `posts` VALUES (4, 3, 'Gracias joksnet...', '<blockquote><p>Gracias a todos por este premio, quisiera compartirlo con la gente que hizo posible esto, a mi familia. Gracias... (ya pasaron los 30 secs ?)</p></blockquote>\r\n<p>Hablando en serio, espero que este sitio cumpla con cosas basicas entre los <em>geeks</em>:</p>\r\n<ul>\r\n    <li>Beautiful is better than ugly.</li>\r\n    <li>Simple is better than complex.</li>\r\n    <li>Complex is better than complicated.</li>\r\n    <li>Now is better than never.</li>\r\n    <li>Although never is often better than *right* now.</li>\r\n</ul>\r\n<p>Partes del texto del <a href="http://www.python.org/dev/peps/pep-0020/">PEP20 The Zen of Python</a>. Saludos.</p>', 'yes', '2006-04-20 15:15:31', '2006-04-21 02:38:57');
INSERT INTO `posts` VALUES (5, 3, 'Freak', '<p>Perdon por el off-topic, pero no podia dejar de mostrar esto al mundo. Alguna vez estuvieron unidos:</p>\r\n<a href="http://joksnet.homelinux.org/community/upload/cimg0297_orig.jpg"><img src="http://joksnet.homelinux.org/community/upload/cimg0297_thumb.jpg" alt="freak" /></a>', 'yes', '2006-04-21 02:06:43', '2006-04-22 19:08:30');
INSERT INTO `posts` VALUES (6, 2, 'Que somos?...', '<blockquote>\r\n<p>\r\nIn current usage, the word freak is used to refer a person with an unusual personality. The older usage, referring to the physically deformed, such as would be seen in a sideshow, is nowadays generally considered offensive and inappropriate.\r\n</p>\r\n<p>\r\nThe word is still used when referring to mutations in plants and animals, but less often for humans. However, lots of people enjoy referring to themselves as freaks...\r\n</p>\r\n</blockquote>\r\n<p>\r\n<a href="http://en.wikipedia.org/wiki/Freak">Freak (Wikipedia)</a>\r\n</p>', 'no', '2006-04-21 13:32:13', '2006-04-21 13:37:43');
INSERT INTO `posts` VALUES (7, 3, 'PHP Games', '<p>Ya que mi objetivo era hablar sobre PHP, aca les dejo un link muy interesante para probar con juegos en PHP, y algunos con PHP+GTK2:</p>\r\n<a href="http://blinduser.blogspot.com/2006/04/php-games.html">http://blinduser.blogspot.com/2006/04/php-games.html</a>\r\n\r\n<p>Saludos,</p>', 'yes', '2006-04-22 01:09:44', '2006-04-27 18:03:55');
INSERT INTO `posts` VALUES (8, 1, 'Sistemas Distribuidos - entrega 1', '<p>Si quisiera hablar de la programaci&oacute;n distribuida en general, remont&aacute;ndome a su historia, sus usos y dem&aacute;s, quiz&aacute;s deba quedarme escribiendo durante d&iacute;as un Post que (mas o menos) cubra la mayor parte de los aspectos (e interpretaciones) de la misma. Aun as&iacute;, no asegurar&iacute;a a los lectores que la informaci&oacute;n que diera fuera toda la existente... (adem&aacute;s se dormir&iacute;an luego de leer cuatro o cinco l&iacute;neas).</p>\r\n<p>Es por eso que decid&iacute; enfocarme en un uso mas que interesante de la "computaci&oacute;n distribuida" llamada Servicios.</p>\r\n<p>En este primer Post (y quiz&aacute;s en el siguiente tambi&eacute;n) voy a intentar dar un Overview del tema, sin mencionar herramientas ni implementaciones de c&oacute;digo (que pueden confundir). Por eso el tema lo tratare a nivel de arquitectura.</p>\r\n<p>La parte acad&eacute;mica de la computaci&oacute;n distribuida no la tratare, ya que para eso deber&iacute;a transcribir alg&oacute;n libro (si si, de esos que te recomiendan en la facultad), y me odiar&iacute;an al segundo Post, as&iacute; que solo la mencionare cuando necesite sustentar una afirmaci&oacute;n por alguna teor&iacute;a.</p>\r\n<h2>Comenzando</h2>\r\n<p>Si nos ponemos a pensar que rol cumplen los dispositivos que nos rodean (Pc, impresora, tel&eacute;fono... etc) nos dar&iacute;amos cuenta que nos prestan un servicio. Un servicio que nosotros identificamos por la funci&oacute;n que nos permite realizar.</p>\r\n<p>Ahora bien, <i>quien "consume" este servicio?</i>, bien, somos nosotros, las personas, es decir, un acotado espectro de entidades que componen el ecosistema.</p>\r\n<p><i>Porque afirmo esto?</i>. Porque podr&iacute;amos permitirnos pensar que cualquier dispositivo "desearia" usar el servicio que presta otro. Cualquier dispositivo que forma este ecosistema deber&iacute;a interactuar con otros. Si siguiera el ejemplo trivial anterior; porque una impresora no puede usar el tel&eacute;fono???. Obviamente no querr&aacute; usarlo para lo mismo que nosotros (hablar), pero si quiz&aacute;s para enviar  y recibir informaci&oacute;n por GPRS.</p>\r\n<p>Ahora bien, alguien pens&oacute; esto alguna vez, y llego a la conclusi&oacute;n de <i>all-in-one</i>. Incorporar la mayor cantidad de funcionalidades dentro de un solo dispositivo. Claro, esto es posible cuando existe alguna relaci&oacute;n entre las capacidades de un dispositivo. Pero... <i>alg&uacute;n fabricante de impresoras pondr&iacute;a la capacidad de transmitir GPRS por dicho dispositivo..???</i> <b>Improbable.</b></p>\r\n<p>As&iacute; nace la idea de que los dispositivos puedan prestar un servicio a cualquier entidad del ecosistema (o ambiente) donde estos se mueven.</p>\r\n<p>La interactividad de estos dispositivos permite realizar una tarea colaborativa entre los mismos, es decir, si A presta una servicio y B lo necesita, <i>porque debemos limitarnos a pensar que A y B no puedan entablar un enlace y B utilizar la funcionalidad de A?</i>.</p>\r\n<p>En sistemas inform&aacute;ticos esto es posible (hasta dir&iacute;a trivial), pero claro, pensemos que dos PC''s son de la misma especie en nuestro ecosistema, con lo cual no es exagerado pensar que la comunicaci&oacute;n entre ellos sea casi natural.</p>\r\n<p>Todas las comunicaciones que se han logrado, han sido <i>fabricadas</i> especialmente. Es decir para el caso en que A deba comunicarse con B. Pero cuando aparezca C que necesite A, nuevamente deber&iacute;amos compatibilizar a C para que entienda a A y ni que hablar si requiere de B.</p>\r\n<p>Este ecosistema es dif&iacute;cil de mantener y desarrollar, pues los dispositivos que a el ingresan no se adaptan al cambio, no hablan un lenguaje com&uacute;n.</p>\r\n<p>Entonces comienza el problema del aislamiento, un dispositivo cumple su funci&oacute;n y se encierra en si mismo, la &uacute;nica interfaz que expone hacia fuera, es decir, a la &uacute;nica entidad que le es permitido usarlo es a aquella para la que se ha desarrollado (si existiera , por supuesto). Nuevamente demasiado acotado.</p>\r\n<p>As&iacute; expuesto da que pensar que todo esto es muy f&aacute;cil. Bien, no lo es, y de hecho, es sumamente complejo.</p>\r\n<p>Cuando uno piensa en este tipo de ecosistema se encuentra que hay puntos muy marcados a resolver. Estos puntos son los que dar&iacute;n tema a mis pr&oacute;ximos Posteos.<br />\r\nEllos son:</p>\r\n<ul>\r\n<li>El problema de la comunicaci&oacute;n, como dos dispositivos entablan una comunicaci&oacute;n, que medio f&iacute;sico aplican.</li>\r\n<li>Como un dispositivo expone su funcionalidad, y como otro puede invocarla </li>\r\n<li>Que tipo de comunicaci&oacute;n pueden entablar</li>\r\n</ul>\r\n<p>No son las &uacute;nicas cosas a tratar, hay mas y mas complejas, pero estas son las b&aacute;sicas, y sin ellas construidas, no podr&iacute;amos hablar del resto.</p>\r\n<p>>> Pronto tendr&eacute; la parte 2....</p>\r\n', 'yes', '2006-04-26 17:24:10', '2006-04-26 17:24:10');
INSERT INTO `posts` VALUES (9, 3, 'Cuantos estamos cerca de esto?', '<p>Se llama S&iacute;ndrome de Asperger y segun la Wikipedia (<a href="http://es.wikipedia.org/wiki/S%C3%ADndrome_de_Asperger">castellano</a> <a href="http://en.wikipedia.org/wiki/Asperger''s_syndrome">ingles</a>):</p>\r\n<blockquote>\r\n<p>El s&iacute;ndrome o trasto\r\no de Asperger es una condici&oacute;n neurol&oacute;gica relacionada con el autismo y com&uacute;nmente calificada como una rara forma de autismo altamente funcional.</p>\r\n<p>Las personas no padecientes de autismo poseen comparativamente un sofisticado sentido de reconocimiento de los estados mentales ajenos. La mayor&iacute;a de las personas son capaces de juntar informaci&oacute;n acerca de los estados cognitivos y emocionales de otras personas basados en pistas otorgadas por el ambiente y el lenguaje corporal de la otra persona. Los autistas no poseen esta habilidad y los individuos padecientes de Asperger en particular pueden ser en su totalidad tan "mentalmente ciegos" como una persona con autismo cl&aacute;sico profundo.</p>\r\n<p>El síndrome de Asperger involucra un intenso nivel de concentraci&oacute;n en temas de inter&eacute;s y es generalmente caracterizado por un don especial. [...] Intereses particularmente comunes entre padecientes son los medios de transporte (por ejemplo los trenes) y las computadoras. En t&eacute;rminos generales son atra&iacute;dos por cosas ordenadas.</p>\r\n<p>Se especula que personas excepcionales y exc&eacute;ntricas que han aportado inmensamente al avance de la civilizaci&oacute;n posiblemente eran Autistas o Aspergers. Los ejemplos m&aacute;s citados son los de Albert Einstein, Isaac Newton y Bill Gates. [...] Se especula que el director Steven Spielberg fue diagnosticado, pero esto no ha sido confirmado. El creador de la franquicia Pokemon, Satoshi Tajiri también sufre de dicho síndrome. [...] Bram Cohen, creador del programa Bittorrent tambi&eacute;n padece S&iacute;ndrome de Asperger.</p>\r\n</blockquote>\r\n<p>Algunas caracter&iacute;sticas del S&iacute;ndrome de Asperger:</p>\r\n<ul>\r\n  <li>No disfruta normalmente del contacto social.</li>\r\n  <li>Se relaciona mejor con adultos que con los niños de su misma edad.</li>\r\n  <li>Tiene problemas al jugar con otros niños.</li>\r\n  <li>No entiende las reglas implícitas del juego.</li>\r\n  <li>Quiere imponer sus propias reglas al jugar con sus pares.</li>\r\n  <li>Quiere ganar siempre cuando juega.</li>\r\n  <li>Prefiere jugar sólo.</li>\r\n  <li>Le cuesta salir de casa.</li>\r\n  <li>El colegio es una fuente de conflictos con los compañeros.</li>\r\n  <li>No le gusta ir al colegio.</li>\r\n  <li>Es fácil objeto de burla y/o abusos por parte de sus compañeros, que se suelen negar a incluirlo en sus equipos.</li>\r\n  <li>No se interesa por practicar deportes en equipo.</li>\r\n  <li>Tiene poca tolerancia a la frustración.</li>\r\n  <li>Cuando quiere algo, lo quiere inmediatamente.</li>\r\n  <li>Le cuesta identificar sus sentimientos y tiene reacciones\r\nemocionales desproporcionadas.</li>\r\n  <li>Llora fácilmente por pequeños motivos.</li>\r\n  <li>Cuando disfruta suele excitarse: saltar, gritar y hacer palmas.</li>\r\n  <li>Tiene más rabietas de lo normal para su edad cuando no consigue algo.</li>\r\n  <li>Le falta empatía: entender intuitivamente los sentimientos de otra persona.</li>\r\n  <li>Puede realizar comentarios ofensivos para otras personas sin darse cuenta, por ejemplo: "que gordo".</li>\r\n  <li>Tiene dificultad para entender las intenciones de los demás.</li>\r\n  <li>No tiene malicia y es sincero.</li>\r\n  <li>Es inocente socialmente, no sabe como actuar en una situación. A veces su conducta es inapropiada y puede parecer desafiante.</li>\r\n  <li>No entiende los niveles apropiados de expresión emocional según las diferentes personas y situaciones: puede besar a un desconocido, saltar en una iglesia, etc.</li>\r\n  <li>No se interesa por la última moda de juguetes, cromos, series TV o ropa.</li>\r\n  <li>No suele mirarte a los ojos cuando te habla.</li>\r\n  <li>Interpreta literalmente frases como: "hay miradas que matan".</li>\r\n  <li>Se cree aquello que se le dice aunque sea disparatado.</li>\r\n  <li>No entiende las ironías (A ti no te gustan los helados), los dobles sentidos, ni los sarcasmos.</li>\r\n  <li>Habla en un tono alto y peculiar: como si fuera extranjero, cantarín o monótono como un robot.</li>\r\n  <li>Posee un lenguaje pedante, hiperformal o hipercorrecto, con un extenso vocabulario.</li>\r\n  <li>Inventa palabras o expresiones idiosincrásicas.</li>\r\n  <li>En ocasiones parece estar ausente (como en la luna), absorto en sus pensamientos.</li>\r\n  <li>Habla mucho.</li>\r\n  <li>Se interesa poco por lo que dicen los otros.</li>\r\n  <li>Le cuesta entender una conversación larga.</li>\r\n  <li>Cambia de tema cuando está confuso.</li>\r\n  <li>Le cuesta trabajo entender el enunciado de un problema con varias frases y necesita que le ayuden explicándoselo por partes.</li>\r\n  <li>Tiene dificultad en entender una pregunta compleja y tarda en responder.</li>\r\n  <li>A menudo no comprende la razón por la que se le riñe, se le critica o se le castiga.</li>\r\n  <li>Le es difícil entender cómo debe portarse en una situación social determinada.</li>\r\n  <li>Se suele poner las zapatillas o la camiseta del revés o no encuentra el camal del pantalón.</li>\r\n  <li>Tiene una memoria excepcional para recordar datos, por ejemplo: fechas de cumpleaños, hechos sin importancia, etc.</li>\r\n  <li>Le gustan las asignaturas lógicas como las matemáticas y las ciencias en general.</li>\r\n  <li>Aprendió a leer solo o con escasa ayuda a una edad temprana.</li>\r\n  <li>Su juego simbólico es escaso (juega poco con muñecos)  y en general demuestra escasa imaginación y creatividad.</li>\r\n  <li>Es original al enfocar un problema o al darle una solución.</li>\r\n  <li>Tiene un sentido del humor peculiar.</li>\r\n  <li>Está fascinado por algún tema en particular y selecciona con avidez información o estadísticas sobre ese interés. Por ejemplo, los números, vehículos, mapas, clasificaciones ligueras o calendarios.</li>\r\n  <li>Ocupa la mayor parte de su tiempo libre en pensar, hablar o escribir sobre su tema.</li>\r\n  <li>Suele hablar de los temas que son de su interés sin darse cuenta si el otro se aburre.</li>\r\n  <li>Repite compulsivamente ciertas acciones o pensamientos. Eso le da seguridad.</li>\r\n  <li>Le gusta la rutina. No tolera bien los cambios imprevistos (rechaza un salida inesperada).</li>\r\n  <li>Tiene rituales elaborados que deben ser cumplidos. Por ejemplo, alinear los juguetes antes de irse a la cama.</li>\r\n  <li>Posee una pobre coordinación motriz.</li>\r\n  <li>No tiene destreza para atrapar una pelota.</li>\r\n  <li>Tiene el niño un ritmo extraño al correr.</li>\r\n  <li>Tiene problemas para vestirse.</li>\r\n  <li>Le cuesta abrocharse los botones o hacer un lazo con la cordonera de los zapatos.</li>\r\n  <li>Miedo, angustia o malestar debido a sonidos ordinarios, como aparatos eléctricos.</li>\r\n  <li>Ligeros roces sobre la piel o la cabeza.</li>\r\n  <li>Llevar determinadas prendas de ropa.</li>\r\n  <li>Ruidos inesperados (la bocina de un coche).</li>\r\n  <li>La visión de ciertos objetos comunes</li>\r\n  <li>Lugares ruidosos y concurridos.</li>\r\n  <li>Ciertos alimentos por su textura, temperatura.</li>\r\n  <li>Una tendencia a agitarse o mecerse cuando está excitado o angustiado.</li>\r\n  <li>Una falta de sensibilidad a niveles bajos de dolor.</li>\r\n  <li>Tardanza en adquirir el habla, en pocos casos.</li>\r\n  <li>Muecas, espasmos o tics faciales inusuales.</li>\r\n  <li>Dificultad para tragar la saliva y babeo.</li>\r\n</ul>', 'no', '2006-04-27 00:25:08', '2006-04-27 01:06:27');
INSERT INTO `posts` VALUES (10, 2, 'Numero de versiones de Ubuntu Linux', '<p>\r\nDespues de haberme preguntado durante meses y meses que representaban los numeros de version de los distintos releases de ubuntu, me di cuenta que ademas de preguntarmelo iba a tener que ponerme a pensar un poquito para resolverlo.\r\n</p>\r\n<p>\r\nSi bien el asunto no es muy complicado (de hecho es bastante sencillo), mi primer acercamiento fue pensar en las versiones anteriores, y note que venian siendo: 5.04, 5.10, 6.04, lo que me daba sospechas de que la proxima fuera 6.10. Bueno, esto parecia cierto hasta hace mas o menos un mes, cuando decidieron retrasar la fecha de release de Dapper (proxima version de ubuntu).\r\n</p>\r\n<p>\r\nDapper ha sido pospuesta dos meses (de abril a junio de 06)\r\nLo que encontramos ahora, es que la nueva version pareceria ser la 6.06, con lo cual se rompia el esquema anterior. Bueno, esto aclara un poco las cosas.\r\nLos numeros de version estan directamente relacionados con la fecha de release. Esta version esta prevista para salir en el a&ntilde;o  2006 (major == 6) y en el mes 06 (minor == 06). Por lo tanto, lo que parecia tan misterioso (al menos para mi) resulta bastante sencillo, obvio y simpatico.\r\n</p>\r\n<p>\r\nProbablemente hubiera sido mas facil buscar el significado en google o en la misma web de ububtu, pero bueno... asi fueron las cosas, y asi seguiran siendo.\r\n</p>\r\n<p>\r\nSaludos a todos los freaks! y hasta la proxima.\r\n</p>', 'yes', '2006-04-27 08:42:57', '2006-04-28 09:08:02');

-- --------------------------------------------------------

-- 
-- Table structure for table `posts2labels`
-- 

DROP TABLE IF EXISTS `posts2labels`;
CREATE TABLE IF NOT EXISTS `posts2labels` (
  `id_posts2labels` bigint(20) NOT NULL auto_increment,
  `id_posts` bigint(20) NOT NULL default '0',
  `id_labels` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id_posts2labels`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `posts2labels`
-- 

INSERT INTO `posts2labels` VALUES (1, 7, 2);
INSERT INTO `posts2labels` VALUES (2, 10, 1);
INSERT INTO `posts2labels` VALUES (3, 3, 6);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_users` bigint(20) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(64) NOT NULL default '',
  `name` varchar(100) NOT NULL default '',
  `description` text NOT NULL,
  PRIMARY KEY  (`id_users`)
) TYPE=MyISAM AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'imsoubelet', 'b623e24add2f342de2acdf8b4edad496', 'Ignacio Soubelet', 'Well-Known as Nacho');
INSERT INTO `users` VALUES (2, 'lcantelmo', '555027e605404a2db2e84342bc35da4d', 'Leonardo Cantelmo', 'It''s me, telmux. Another invention of the society!');
INSERT INTO `users` VALUES (3, 'joksnet', 'd4dc1861c4231d27a8d0811b130fd8ee', 'Juan Manuel Martinez', 'a.k.a. joksnet');
INSERT INTO `users` VALUES (4, 'pablogrigo', 'e7be505e8a9e77c45962477c520d791e', 'Pablo Grigolatto', 'El mas cuerdo de los 100');
